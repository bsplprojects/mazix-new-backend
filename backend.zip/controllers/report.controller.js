import sql from "mssql";
import { poolPromise } from "../db.js";
import { getProductSaleWithJoin } from "../helpers/getSaleProduct.js";

export async function getSaleReport(req, res) {
  try {
    const { FromDate, MemberId, Todate, page = 1, pageSize = 10 } = req.query;

    const pool = await poolPromise;

    const result = await pool
      .request()
      .input("memberID", sql.NVarChar, MemberId || "")
      .input("fromDate", sql.NVarChar, FromDate || "")
      .input("toDate", sql.NVarChar, Todate || "")
      .execute("Get_MemberEnrolledReport");

    return res.status(200).json({
      success: true,
      data: result.recordset,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      success: false,
      msg: "Internal Server Error",
      err: error.message,
    });
  }
}

export async function getTDSReport(req, res) {
  try {
    const { MemberId, FromDate, Todate } = req.query;

    const pool = await poolPromise;

    const result = await pool
      .request()
      .input("MemberID", sql.NVarChar(sql.MAX), MemberId || "")
      .input("Fromdate", sql.NVarChar(sql.MAX), FromDate || "")
      .input("Todate", sql.NVarChar(sql.MAX), Todate || "")
      .execute("Get_TDSAdminReportFinal");

    return res.status(200).json({
      success: true,
      data: result.recordset,
    });
  } catch (error) {
    console.error("getTDSDetail Error:", error);

    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
}

export async function getAdminChargeDetail(req, res) {
  try {
    const { MemberId, FromDate, Todate } = req.query;

    const pool = await poolPromise;

    const result = await pool
      .request()
      .input("MemberID", sql.NVarChar(sql.MAX), MemberId || "")
      .input("Fromdate", sql.NVarChar(sql.MAX), FromDate || "")
      .input("Todate", sql.NVarChar(sql.MAX), Todate || "")
      .execute("Get_AdminChargeReport");

    return res.status(200).json({
      success: true,
      data: result.recordset,
    });
  } catch (error) {
    console.error("getAdminChargeDetail Error:", error);

    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
}

export async function getRepurchaseWalletTransfer(req, res) {
  try {
    const { MemberId, FromDate, Todate } = req.query;

    const pool = await poolPromise;

    const request = pool.request();

    let where = ["LOWER(Status) = 'active'"];

    if (MemberId) {
      request.input("MemberID", sql.NVarChar(sql.MAX), MemberId.toLowerCase());
      where.push("LOWER(MemberID) = @MemberID");
    }

    if (FromDate && Todate) {
      request.input("Fromdate", sql.Date, FromDate);
      request.input("Todate", sql.Date, Todate);
      where.push("[Date] BETWEEN @Fromdate AND @Todate");
    }

    const whereClause = where.join(" AND ");

    const result = await request.query(`
          SELECT *
          FROM RepurchaseWalletTransfer
          WHERE ${whereClause}
          ORDER BY [Date] DESC
      `);

    const totalSend = await pool
      .request()
      .input("MemberID", sql.NVarChar(sql.MAX), MemberId || "")
      .input("Fromdate", sql.NVarChar(sql.MAX), FromDate || "")
      .input("Todate", sql.NVarChar(sql.MAX), Todate || "").query(`
      SELECT SUM(Amount) as TotalSend FROM RepurchaseWalletTransfer WHERE MemberID = @MemberID OR Date BETWEEN @Fromdate AND @Todate AND LOWER(Status) = 'active' AND LOWER(Flag) = 'send'
    `);

    const totalReceived = await pool
      .request()
      .input("MemberID", sql.NVarChar(sql.MAX), MemberId || "")
      .input("Fromdate", sql.NVarChar(sql.MAX), FromDate || "")
      .input("Todate", sql.NVarChar(sql.MAX), Todate || "").query(`
      SELECT SUM(Amount) as TotalReceived FROM RepurchaseWalletTransfer WHERE MemberID = @MemberID OR Date BETWEEN @Fromdate AND @Todate AND LOWER(Status) = 'active' AND LOWER(Flag) = 'received'
    `);

    return res.status(200).json({
      success: true,
      data: result.recordset,
      totalSend: totalSend.recordset[0].TotalSend,
      totalReceived: totalReceived.recordset[0].TotalReceived,
    });
  } catch (error) {
    console.error("getAdminChargeDetail Error:", error);

    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
}

export async function getWalletTransferReport(req, res) {
  try {
    const { MemberId, FromDate, Todate } = req.query;

    const pool = await poolPromise;

    let walletTransfer = [];

    if (MemberId || FromDate || Todate) {
      const result = await pool
        .request()
        .input("memberID", sql.NVarChar, MemberId || "")
        .input("fromDate", sql.NVarChar, FromDate || "")
        .input("toDate", sql.NVarChar, Todate || "")
        .execute("Get_WalletTransferReport");

      walletTransfer = result.recordset;

      const totalSend = walletTransfer
        .filter((x) => x.Flag === "Send")
        .reduce((sum, x) => sum + Number(x.Amount || 0), 0);

      const totalReceived = walletTransfer
        .filter((x) => x.Flag === "Received")
        .reduce((sum, x) => sum + Number(x.Amount || 0), 0);

      return res.json({
        success: true,
        totalSend,
        totalReceived,
        data: walletTransfer,
      });
    } else {
      const result = await pool
        .request()
        .input("MemberID", sql.NVarChar, "")
        .input("Fromdate", sql.NVarChar, "")
        .input("Todate", sql.NVarChar, "")
        .execute("Get_WalletTransferReport");

      return res.json({
        success: true,
        totalSend: 0,
        totalReceived: 0,
        data: result.recordset,
      });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({
      success: false,
      message: err.message,
    });
  }
}

export async function getRepurchaseReport(req, res) {
  try {
    const { MemberID, Fromdate, Todate } = req.query;

    const pool = await poolPromise;

    const request = pool.request();

    let whereClause = "WHERE 1=1";

    if (MemberID) {
      whereClause += " AND MemberID = @MemberID";
      request.input("MemberID", sql.VarChar, MemberID);
    }

    if (Fromdate) {
      whereClause += " AND CAST(OrderDate AS DATE) >= CAST(@Fromdate AS DATE)";
      request.input("Fromdate", sql.DateTime, Fromdate);
    }

    if (Todate) {
      whereClause += " AND CAST(OrderDate AS DATE) <= CAST(@Todate AS DATE)";
      request.input("Todate", sql.DateTime, Todate);
    }

    const result = await request.query(`
      SELECT RepOrderId, MemberID, MID, OrderNo, OrderDate, TotalAmount, TotalGST, TotalBV, OrderStatus FROM RepProductOrder

    ${whereClause}

    ORDER BY OrderDate DESC
  `);

    return res.status(200).json({
      success: true,
      data: result.recordset,
    });
  } catch (error) {
    console.error("getRepTransferHistory Error:", error);

    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
}

export async function getPayTransferReport(req, res) {
  try {
    const { dateList, memberId } = req.query;

    const pool = await poolPromise;

    const result = await pool
      .request()
      .input("fromDate", sql.NVarChar(sql.MAX), dateList || "")
      .input("MemberID", sql.NVarChar(sql.MAX), memberId || "")
      .execute("Get_MemberPaymentTransferedDetail");

    return res.status(200).json({
      success: true,
      data: result.recordset,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      success: false,
      msg: "Internal Server Error",
      err: error.message,
    });
  }
}

export async function getRewardReport(req, res) {
  try {
    const {
      MemberId,
      Designation,
      FromDate,
      Todate,
      page = 1,
      pageSize = 10,
    } = req.query;

    const pool = await poolPromise;

    const isAll = pageSize === "all";

    const pageNumber = parseInt(page, 10);
    const size = isAll ? null : parseInt(pageSize, 10);
    const offset = isAll ? 0 : (pageNumber - 1) * size;

    let whereClause = "WHERE 1=1 AND mrs.Flag = '2025-26'";

    const countRequest = pool.request();
    const dataRequest = pool.request();

    if (MemberId) {
      whereClause += " AND mrs.MemberID = @MemberID";
      countRequest.input("MemberID", sql.VarChar, MemberId);
      dataRequest.input("MemberID", sql.VarChar, MemberId);
    }

    if (Designation) {
      whereClause += " AND mrs.Designation = @Designation";
      countRequest.input("Designation", sql.VarChar, Designation);
      dataRequest.input("Designation", sql.VarChar, Designation);
    }

    if (FromDate) {
      whereClause += " AND mrs.ModifyDate >= @FromDate";

      const from = new Date(`${FromDate}T00:00:00`);

      countRequest.input("FromDate", sql.DateTime, from);
      dataRequest.input("FromDate", sql.DateTime, from);
    }

    if (Todate) {
      whereClause += " AND mrs.ModifyDate < DATEADD(DAY,1,@Todate)";

      const to = new Date(`${Todate}T00:00:00`);

      countRequest.input("Todate", sql.DateTime, to);
      dataRequest.input("Todate", sql.DateTime, to);
    }

    const countResult = await countRequest.query(`
      SELECT COUNT(*) AS total
      FROM MemberRewardSection mrs
      ${whereClause}
    `);

    const total = countResult.recordset[0].total;

    if (!isAll) {
      dataRequest
        .input("Offset", sql.Int, offset)
        .input("PageSize", sql.Int, size);
    }

    const paginationQuery = isAll
      ? ""
      : `
        OFFSET @Offset ROWS
        FETCH NEXT @PageSize ROWS ONLY
      `;

    const result = await dataRequest.query(`
      SELECT
          mrs.RewardID,
          mrs.MemberID,
          mpi.MemberName AS Flag,
          mpi.ContactNo AS RequiredBV,
          mrs.Designation,
          mrs.RewardName,
          mrs.RequiredPV,
          mrs.AchievedPV,
          mrs.AchievedBV,
          mrs.AchievedPVAmt,
          mrs.AchievedBVAmt,
          mrs.Status,
          mrs.ModifyDate,
          mrs.Flag as Year
      FROM MemberRewardSection mrs
      LEFT JOIN MemberPersonalInfo mpi
          ON mpi.MemberID = mrs.MemberID
      ${whereClause}
      ORDER BY mrs.ModifyDate DESC
      ${paginationQuery}
    `);

    return res.status(200).json({
      success: true,
      data: result.recordset,
      pagination: isAll
        ? null
        : {
            page: pageNumber,
            pageSize: size,
            total,
            totalPages: Math.ceil(total / size),
            hasNext: pageNumber < Math.ceil(total / size),
            hasPrev: pageNumber > 1,
          },
    });
  } catch (error) {
    console.error("getRewardReport Error:", error);

    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
}

export async function getProductSaleReport(req, res) {
  try {
    const { MemberId, FromDate, Todate } = req.query;

    const pool = await poolPromise;

    const result = await pool
      .request()
      .input("MemberID", sql.VarChar, MemberId)
      .input("Fromdate", sql.VarChar, FromDate)
      .input("Todate", sql.VarChar, Todate)
      .execute("Get_SaleProductWiseJoin");

    const data = result.recordset;

    return res.status(200).json({ success: true, data });
  } catch (error) {
    console.error("Error :", error);
    return res
      .status(500)
      .json({ success: false, msg: "Internal Server Error" });
  }
}

export async function getProductSaleWithJoining(req, res) {
  try {
    const { MemberID, Fromdate, Todate } = req.query;

    let data;

    if (MemberID && Fromdate && Todate) {
      data = await getProductSaleWithJoin({
        MemberID,
        Fromdate,
        Todate,
      });
    } else if (Fromdate && Todate) {
      data = await getProductSaleWithJoin({
        Fromdate,
        Todate,
      });
    } else if (MemberID) {
      data = await getProductSaleWithJoin({
        MemberID,
      });
    } else {
      const today = new Date().toISOString().split("T")[0];

      data = await getProductSaleWithJoin({
        Fromdate: today,
        Todate: today,
      });
    }

    return res.status(200).json({
      success: true,
      count: data.length,
      data,
    });
  } catch (err) {
    console.error(err);

    return res.status(500).json({
      success: false,
      message: err.message,
    });
  }
}

export async function getProductList(req, res) {
  try {
    try {
      const { MemberID } = req.query;

      if (!MemberID) {
        return res.status(400).json({
          success: false,
          message: "MemberID is required",
        });
      }

      const pool = await poolPromise;

      // Get Member Details
      const memberResult = await pool
        .request()
        .input("MemberID", sql.VarChar, MemberID).query(`
        SELECT MID, StateID
        FROM MemberPersonalInfo
        WHERE MemberID = @MemberID
      `);

      const member = memberResult.recordset[0];

      if (!member) {
        return res.status(404).json({
          success: false,
          message: "Member not found",
        });
      }

      const mid = Number(member.MID);
      const stateId = Number(member.StateID || 0);

      // Get Products
      const productResult = await pool.request().input("MID", sql.BigInt, mid)
        .query(`
        SELECT
          p.Product,
          p.GST,
          d.MRP,
          d.MemberMRP,
          d.Qty
        FROM MemberProductActivationParticular d
        INNER JOIN ProductMaster p
          ON d.ProductID = p.pID
        WHERE d.MID = @MID
      `);

      let totalTaxable = 0;

      const data = productResult.recordset.map((item) => {
        const totalMemberMRP =
          Number(item.MemberMRP || 0) * Number(item.Qty || 0);

        const obj = {
          ProductName: item.Product,
          MRP: Number(item.MRP || 0),
          MemberMRP: Number(item.MemberMRP || 0),
          Qty: Number(item.Qty || 0),
          GST: Number(item.GST || 0),
        };

        // Jharkhand (StateID = 20)
        if (stateId === 20) {
          const halfGST = Number(item.GST) / 2;

          const cgst = (totalMemberMRP * halfGST) / (100 + halfGST);

          const sgst = (totalMemberMRP * halfGST) / (100 + halfGST);

          obj.CGST = Number(cgst.toFixed(2));
          obj.SGST = Number(sgst.toFixed(2));
          obj.IGST = 0;

          obj.CGSTPer = Math.round(halfGST);
          obj.SGSTPer = Math.round(halfGST);
          obj.IGSTPer = 0;

          obj.TaxAbleAmnt =
            totalMemberMRP -
            (Number(cgst.toFixed(2)) + Number(sgst.toFixed(2)));
        } else {
          const igst =
            (totalMemberMRP * Number(item.GST)) / (100 + Number(item.GST));

          obj.IGST = Number(igst.toFixed(2));
          obj.CGST = 0;
          obj.SGST = 0;

          obj.IGSTPer = Math.round(Number(item.GST));
          obj.CGSTPer = 0;
          obj.SGSTPer = 0;

          obj.TaxAbleAmnt = totalMemberMRP - Number(igst.toFixed(2));
        }

        totalTaxable += obj.TaxAbleAmnt;

        obj.TotalTaxAbleAmnt = Number(totalTaxable.toFixed(2));

        return obj;
      });

      return res.status(200).json({
        success: true,
        count: data.length,
        data,
      });
    } catch (error) {
      console.error("GetProductList Error:", error);

      return res.status(500).json({
        success: false,
        message: error.message,
      });
    }
  } catch (error) {
    console.error(err);
    return res.status(500).json({
      success: false,
      message: err.message,
    });
  }
}

export async function getPurchaseReport(req, res) {
  try {
    let { FromDate, ToDate, MemberID, OrderNo, PayMode, DeliveryStatus } =
      req.query;

    const pool = await poolPromise;

    let query = `
      SELECT 
        om.OrderNo,
        om.OrderDate,
        om.Name AS CustomerName,
        om.Phone,
        om.City,
        om.TotalAmount,
        om.PayMode,
        om.DeliveryPartner,
        om.TrackingID,

        CASE 
          WHEN om.DeliveryStatus IS NULL OR om.DeliveryStatus = '' 
          THEN 'Pending'
          ELSE om.DeliveryStatus
        END AS DeliveryStatus,

        ISNULL(SUM(oi.Qty), 0) AS ItemCount,
        ISNULL(SUM(oi.CGST), 0) AS TotalCGST,
        ISNULL(SUM(oi.SGST), 0) AS TotalSGST,
        ISNULL(SUM(oi.IGST), 0) AS TotalIGST,
        ISNULL(SUM(oi.CGST + oi.SGST + oi.IGST), 0) AS TotalGST

      FROM OrderMaster om
      LEFT JOIN OrderItems oi ON oi.OrderID = om.OrderNo
      WHERE 1=1
    `;

    let request = pool.request();

    if (FromDate) {
      query += ` AND om.OrderDate >= @FromDate`;
      request.input("FromDate", sql.DateTime, new Date(FromDate));
    }

    if (ToDate) {
      query += ` AND om.OrderDate < @ToDate`;
      request.input(
        "ToDate",
        sql.DateTime,
        new Date(new Date(ToDate).getTime() + 24 * 60 * 60 * 1000),
      );
    }

    if (OrderNo) {
      query += ` AND om.OrderNo LIKE @OrderNo`;
      request.input("OrderNo", sql.VarChar, `%${OrderNo}%`);
    }

    if (MemberID) {
      query += ` AND CAST(om.MemberID AS VARCHAR) = @MemberID`;
      request.input("MemberID", sql.VarChar, MemberID);
    }

    if (PayMode) {
      query += ` AND om.PayMode = @PayMode`;
      request.input("PayMode", sql.VarChar, PayMode);
    }

    if (DeliveryStatus && DeliveryStatus !== "All") {
      if (DeliveryStatus === "Pending") {
        query += ` AND (om.DeliveryStatus IS NULL OR om.DeliveryStatus = '')`;
      } else {
        query += ` AND om.DeliveryStatus = @DeliveryStatus`;
        request.input("DeliveryStatus", sql.VarChar, DeliveryStatus);
      }
    }

    query += `
      GROUP BY 
        om.OrderNo,
        om.OrderDate,
        om.Name,
        om.Phone,
        om.City,
        om.TotalAmount,
        om.PayMode,
        om.DeliveryPartner,
        om.TrackingID,
        om.DeliveryStatus
      ORDER BY om.OrderDate DESC
    `;

    const result = await request.query(query);

    return res.json({
      status: true,
      totalRecords: result.recordset.length,
      data: result.recordset,
    });
  } catch (err) {
    return res.json({
      status: false,
      message: err.message,
    });
  }
}

export async function getRepurchaseVoucherReport(req, res) {
  try {
    const { MemberId, FromDate, Todate } = req.query;

    const pool = await poolPromise;

    const request = pool.request();

    request.input("MemberID", sql.VarChar, MemberId || null);
    request.input("Fromdate", sql.VarChar, FromDate || null);
    request.input("Todate", sql.VarChar, Todate || null);

    const result = await request.execute("Get_AdminMemberRepurchase");

    let data = result.recordset || [];

    const sync = data.filter((z) => z.OrderStatus && z.OrderStatus === "VOCH");

    return res.json(sync);
  } catch (err) {
    return res.json({
      status: false,
      message: err.message,
    });
  }
}

export async function getVerificationList(req, res) {
  try {
    const { MemberID, Status, page = 1, pageSize = 10 } = req.query;

    const pool = await poolPromise;

    // const offset = (Number(page) - 1) * Number(pageSize);

    // Call stored procedure
    const result = await pool
      .request()
      .input("memberID", sql.VarChar, MemberID)
      .input("fromDate", sql.VarChar, Status)
      .input("toDate", sql.VarChar, "")
      .execute("Get_MemberKYCVefivation");

    const rows = result.recordset;

    const grouped = {};

    rows.forEach((item) => {
      const id = item.KYCMemberID;

      if (!grouped[id]) {
        grouped[id] = {
          KYCMemberID: id,
          MemberName: item.MemberName,
          KYCStatus: item.KYCStatus,
          PHOTO: null,
          PAN: null,
          AADHAR: null,
          PASSBOOK: null,
        };
      }

      // map documents
      if (item.DocName === "PHOTO") {
        grouped[id].PHOTO = item.DocPath;
      } else if (item.DocName === "PAN") {
        grouped[id].PAN = item.DocPath;
      } else if (item.DocName === "AADHAR") {
        grouped[id].AADHAR = item.DocPath;
      } else if (item.DocName === "BANK PASSBOOK") {
        grouped[id].PASSBOOK = item.DocPath;
      }
    });

    return res.json(Object.values(grouped));
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Server Error" });
  }
}

export async function getPaidDatesPayout(req, res) {
  try {
    const pool = await poolPromise;

    const result = await pool.request().execute("Get_PaymentDate");

    const data = result.recordset || [];

    const response = data.map((row) => {
      const dt = new Date(row.PaymentDate);

      const year = dt.getFullYear();
      const month = dt.getMonth() + 1;
      const day = dt.getDate();

      return {
        Status: `${day}-${month}-${year}`,
        Flag: `${year}-${month}-${day}`,
      };
    });

    return res.status(200).json({
      success: true,
      data: response,
    });
  } catch (error) {
    return res
      .status(500)
      .json({ msg: "Internal Server Error", err: error.message });
  }
}

export async function getGSTReport(req, res) {
  try {
    let { FromDate, ToDate, month, page = 1, pageSize = 10 } = req.query;

    page = Number(page);
    const isAll = pageSize === "all";
    pageSize = isAll ? null : Number(pageSize);
    const offset = isAll ? 0 : (page - 1) * pageSize;

    const pool = await poolPromise;
    const request = pool.request();

    let where = "WHERE 1=1";

    if (FromDate) {
      request.input("FromDate", sql.Date, FromDate);
      where += " AND OrderDate >= @FromDate";
    }

    if (ToDate) {
      request.input("ToDate", sql.Date, ToDate);
      where += " AND OrderDate <= @ToDate";
    }

    if (month) {
      const [year, monthNumber] = month.split("-");

      request.input("Year", sql.Int, Number(year));
      request.input("Month", sql.Int, Number(monthNumber));

      where += `
          AND YEAR(OrderDate) = @Year
          AND MONTH(OrderDate) = @Month
      `;
    }

    const countQuery = `
      SELECT COUNT(*) AS totalRecords
      FROM RepProductOrder
      ${where}
    `;

    const countResult = await request.query(countQuery);
    const totalRecords = countResult.recordset[0].totalRecords;

    const dataRequest = pool.request();

    if (FromDate) dataRequest.input("FromDate", sql.Date, FromDate);
    if (ToDate) dataRequest.input("ToDate", sql.Date, ToDate);
    if (month) {
      const [year, monthNumber] = month.split("-");

      dataRequest.input("Year", sql.Int, Number(year));
      dataRequest.input("Month", sql.Int, Number(monthNumber));
    }

    let dataQuery = `
    SELECT *
    FROM RepProductOrder
    ${where}
    ORDER BY OrderDate DESC
`;

    if (!isAll) {
      dataQuery += `
    OFFSET ${offset} ROWS
    FETCH NEXT ${pageSize} ROWS ONLY
  `;
    }

    const result = await dataRequest.query(dataQuery);

    // TOtal GST till date and this month and between from date and to date
    const totalGSTRequest = pool.request();

    if (FromDate) totalGSTRequest.input("FromDate", sql.Date, FromDate);
    if (ToDate) totalGSTRequest.input("ToDate", sql.Date, ToDate);
    if (month) {
      const [year, monthNumber] = month.split("-");

      totalGSTRequest.input("Year", sql.Int, Number(year));
      totalGSTRequest.input("Month", sql.Int, Number(monthNumber));
    }

    const totalGSTQuery = `
      SELECT SUM(TotalGST) AS totalGST
      FROM RepProductOrder
      ${where}
    `;

    const totalGSTResult = await totalGSTRequest.query(totalGSTQuery);

    const totalGST = totalGSTResult.recordset[0].totalGST || 0;

    return res.status(200).json({
      success: true,
      msg: "Fetched successfully",
      page: isAll ? 1 : page,
      pageSize: isAll ? totalRecords : pageSize,
      totalRecords,
      totalPages: isAll ? 1 : Math.ceil(totalRecords / pageSize),
      data: result.recordset,
      totalGST,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: false,
      msg: "Internal Server Error",
      err: error.message,
    });
  }
}

export async function getStockReports(req, res) {
  try {
    const {
      FromDate,
      ToDate,
      status = "all",
      page = 1,
      pageSize = 10,
      search,
    } = req.query;

    const pageNumber = parseInt(page, 10);
    const size = parseInt(pageSize, 10);
    const offset = (pageNumber - 1) * size;

    const pool = await poolPromise;

    let whereClause = "WHERE 1=1";

    if (status && status.toLowerCase() !== "all") {
      whereClause += " AND LOWER(Status) = LOWER(@Status)";
    }

    if (FromDate) {
      whereClause += " AND CreatedAt >= @FromDate";
    }

    if (ToDate) {
      whereClause += " AND CreatedAt < DATEADD(DAY, 1, @ToDate)";
    }

    if (search) {
      whereClause += `
          AND (
            sd.Product LIKE @Search
          )
      `;
    }

    const countRequest = pool.request();

    if (status && status.toLowerCase() !== "all") {
      countRequest.input("Status", sql.NVarChar, status);
    }

    if (FromDate) {
      countRequest.input("FromDate", sql.DateTime, new Date(FromDate));
    }

    if (ToDate) {
      countRequest.input("ToDate", sql.DateTime, new Date(ToDate));
    }

    if (search) {
      countRequest.input("Search", sql.NVarChar, `%${search}%`);
    }

    const countResult = await countRequest.query(`
      SELECT COUNT(*) AS total
        FROM stockDetail sd
        LEFT JOIN ProductMaster pm ON sd.pID = pm.pID
      ${whereClause}
    `);

    const total = countResult.recordset[0].total;

    const dataRequest = pool.request();

    if (status && status.toLowerCase() !== "all") {
      dataRequest.input("Status", sql.NVarChar, status);
    }

    if (FromDate) {
      dataRequest.input("FromDate", sql.DateTime, new Date(FromDate));
    }

    if (ToDate) {
      dataRequest.input("ToDate", sql.DateTime, new Date(ToDate));
    }

    if (search) {
      dataRequest.input("Search", sql.NVarChar, `%${search}%`);
    }

    dataRequest
      .input("Offset", sql.Int, offset)
      .input("PageSize", sql.Int, size);

    const result = await dataRequest.query(`
      SELECT sd.*, ISNULL(pm.stock, 0) AS openingStock
      FROM stockDetail sd LEFT JOIN ProductMaster pm ON sd.pID = pm.pID
      ${whereClause}
      ORDER BY CreatedAt DESC
      OFFSET @Offset ROWS
      FETCH NEXT @PageSize ROWS ONLY
    `);

    return res.status(200).json({
      success: true,
      stocksList: result.recordset,
      pagination: {
        page: pageNumber,
        pageSize: size,
        total,
        totalPages: Math.ceil(total / size),
        hasNext: pageNumber < Math.ceil(total / size),
        hasPrev: pageNumber > 1,
      },
    });
  } catch (error) {
    console.error("getStockReports Error:", error);

    return res.status(500).json({
      success: false,
      msg: "Internal Server Error",
      error: error.message,
    });
  }
}

export async function generatePayoutReport(req, res) {
  try {
    const { FromDate, MemberId, Todate, page, pageSize } = req.query;

    const pool = await poolPromise;

    const result = await pool
      .request()
      .input("FromDate", sql.Date, FromDate)
      .input("ToDate", sql.Date, Todate)
      .input("ModifyDate", sql.Date, "2026-07-11");
    // .execute("usp_GenerateMemberDownlineCount");

    return res.status(200).json({
      success: true,
      msg: "OK",
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      msg: "Internal Server Error",
      err: error.message,
    });
  }
}
