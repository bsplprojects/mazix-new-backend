import sql from "mssql";
import { poolPromise } from "../db.js";

export const getRepurchaseHistory = async (req, res) => {
  try {
    const { fDate, tDate, limit } = req.query;

    const memid = req.params.memberID;

    if (!memid) {
      return res.status(401).json({
        success: false,
        message: "Unauthorized",
      });
    }

    const pool = await poolPromise;

    const result = await pool
      .request()
      .input("MemberID", sql.VarChar, memid)
      .input("FDate", sql.Date, new Date(fDate))
      .input("limit", sql.Int, limit)
      .input("TDate", sql.Date, new Date(tDate)).query(`
        SELECT TOP(@limit) *
        FROM RepProductOrder
        WHERE MemberID = @MemberID
          AND OrderDate >= @FDate
          AND OrderDate <= @TDate
        ORDER BY RepOrderID DESC 
      `);

    return res.status(200).json(result.recordset);
  } catch (error) {
    console.error("Get Product Rep List Search Error:", error);
    return res.status(500).json({
      success: false,
      message: "Server Error",
      error: error.message,
    });
  }
};

export const getRepVoucherWalletAmount = async (req, res) => {
  try {
    const { Prefix, memberID } = req.query;

    const pool = await poolPromise;

    let rtn = {
      Repurchase: 0,
      Voucher: 0,
    };

    if (Prefix === "Repurchase") {
      const result = await pool
        .request()
        .input("memberID", memberID)
        .execute("Get_RepMainWallet");

      const value = Object.values(result.recordset?.[0])[0] || 0;

      rtn.Repurchase = value;
    } else if (Prefix === "Voucher") {
      const result = await pool
        .request()
        .input("memberID", memberID)
        .execute("Get_VoucherAmount");

      const voucher = result.recordset?.[0]?.TotalVoucher || 0;

      rtn.Voucher = voucher;
    }

    return res.status(200).json(rtn);
  } catch (error) {
    console.error("GetMemberWalletAmount Error:", error);
    return res.status(500).json({ message: "Server Error" });
  }
};

export const insertRepProduct = async (req, res) => {
  const kotbills = req.body.kotbills;

  let kotid = 0;
  let tBV = 0;
  let tAMT = 0;
  let tgst = 0;

  try {
    const pool = await poolPromise;

    const memberID = req.query.memberID;
    const MID = req.query.mid;

    if (!kotbills || kotbills.length === 0) {
      return res.status(400).json({
        success: false,
        message: "KOTBills is required",
        kotid,
      });
    }

    if (kotbills[0].Flag.toLowerCase() === "repurchase") {
      const reWalletResult = await pool
        .request()
        .input("memberID", sql.NVarChar, memberID)
        .execute("Get_RepMainWallet");

      const getReWall = reWalletResult.recordset[0];

      if (
        getReWall &&
        Number(kotbills[0].TotalAmount) <= Number(getReWall.Value)
      ) {
        const catId = Number(kotbills[0].pCatID);

        if (kotbills.length > 0) {
          const countResult = await pool.request().query(`
            SELECT COUNT(*) AS cnt FROM RepProductOrder
          `);
          const orderCount = countResult.recordset[0].cnt;

          const orderNo = `MZX/OR/${orderCount}`;
          const repCurrentWallet =
            Number(getReWall.Value) - Number(kotbills[0].TotalAmount);

          const repPrevWallet = getReWall.Value;

          // inserting header
          const insertHeaderResult = await pool
            .request()
            .input("MemberID", sql.NVarChar, memberID)
            .input("MID", sql.BigInt, Number(MID))
            .input("OrderNo", sql.NVarChar, orderNo)
            .input(
              "OrderDate",
              sql.DateTime,
              new Date(new Date().toDateString()),
            )
            .input("RepCurrentWallet", sql.Decimal(18, 2), repCurrentWallet)
            .input("RepPrevWallet", sql.Decimal(18, 2), repPrevWallet)
            .input("OrderStatus", sql.NVarChar, "RPO")
            .input("Status", sql.NVarChar, "Active")
            .input("ModifyDate", sql.DateTime, new Date()).query(`
              INSERT INTO RepProductOrder
                (MemberID, MID, OrderNo, OrderDate, RepCurrentWallet, RepPrevWallet, OrderStatus, Status, ModifyDate) OUTPUT INSERTED.RepOrderID
              VALUES (
                @MemberID, @MID, @OrderNo, @OrderDate,  @RepCurrentWallet, @RepPrevWallet, @OrderStatus,
                @Status, @ModifyDate
              )
            `);

          kotid = insertHeaderResult.recordset[0].RepOrderID;

          // loop over kotbills and insert
          for (let i = 0; i < kotbills.length; i++) {
            const item = kotbills[i];

            const netAmount = Number(item.MRP) * Number(item.Qty);
            const tBV = tBV + Number(item.BV) * Number(item.Qty);
            const tAMT = tAMT + Number(item.MRP) * Number(item.Qty);

            const PID = Number(item.PID);
            const productResult = await pool
              .request()
              .input("PID", sql.BigInt, PID)
              .query(`SELECT * FROM ProductMaster WHERE ID = @PID`);

            const Pobj = productResult.recordset[0];

            const lgst = (Number(item.MRP) * Number(Pobj.GST)) / 100;
            tgst = tgst + (Number(item.MRP) * Number(Pobj.GST)) / 100;

            await pool
              .request()
              .input("RepOrderID", sql.BigInt, kotid)
              .input("MemberID", sql.NVarChar, memberID)
              .input("MID", sql.BigInt, Number(MID))
              .input("pID", sql.BigInt, Number(item.pID))
              .input("pCatID", sql.BigInt, Number(item.pCatID))
              .input("MRP", sql.Decimal(18, 2), Number(item.MRP))
              .input("BV", sql.Decimal(18, 2), Number(item.BV))
              .input("Qty", sql.Int, Number(item.Qty))
              .input("ModifyDate", sql.DateTime, new Date())
              .input("NetAmount", sql.Decimal(18, 2), netAmount)
              .input("Status", sql.NVarChar, "Active")
              .input("LGST", sql.Decimal(18, 2), lgst).query(`
                INSERT INTO RepProductOrderList (RepOrderID, MemberID, MID, pID, pCatID, MRP, BV, Qty, ModifyDate, NetAmount, Status, LGST)
                VALUES (
                @RepOrderID, @MemberID, @MID, @pID, @pCatID, @MRP, @BV, @Qty, @ModifyDate, @NetAmount, @Status, @LGST)
              `);
          }

          // update header totals
          await pool
            .request()
            .input("RepOrderID", sql.BigInt, kotid)
            .input("TotalBV", sql.Decimal(18, 2), tBV)
            .input("TotalAmount", sql.Decimal(18, 2), tAMT)
            .input("TotalGST", sql.Decimal(18, 2), tgst).query(`
            UPDATE RepProductOrder
            SET TotalBV = @TotalBV,
                TotalAmount = @TotalAmount,
                TotalGST = @TotalGST
            WHERE RepOrderID = @RepOrderID  
          `);
        }
      }
    } else if (kotbills[0].Flag === "Voucher") {
      const voucherResult = await pool
        .request()
        .input("MemberID", sql.NVarChar, memberID.execute("Get_VoucherAmount"));

      const getReWall = voucherResult.recordset[0];

      if (
        getReWall &&
        Number(kotbills[0].TotalAmount) <= Number(getReWall.TotalVoucher)
      ) {
        const catid = Number(kotbills[0].pCatID);

        if (kotbills.length > 0) {
          const countResult = await pool.request().query(`
              SELECT COUNT(*) AS cnt FROM RepProductOrder              
            `);
          const orderCount = countResult.recordset[0].cnt;

          const orderNo = `MZX/OR/${orderCount}`;
          const repCurrentWallet =
            Number(getReWall.TotalVoucher) - Number(kotbills[0].TotalAmount);
          const repPrevWallet = getReWall.TotalVoucher;

          const insertHeaderResult = await pool
            .request()
            .input("MemberID", sql.NVarChar, userName)
            .input("MID", sql.BigInt, Number(MID))
            .input("OrderNo", sql.NVarChar, orderNo)
            .input(
              "OrderDate",
              sql.DateTime,
              new Date(new Date().toDateString()),
            )
            .input("RepCurrentWallet", sql.Decimal(18, 2), repCurrentWallet)
            .input("RepPrevWallet", sql.Decimal(18, 2), repPrevWallet)
            .input("OrderStatus", sql.NVarChar, "VOCH")
            .input("Status", sql.NVarChar, "Active")
            .input("ModifyDate", sql.DateTime, new Date()).query(`
              INSERT INTO RepProductOrder
              (MemberID, MID, OrderNo, OrderDate, RepCurrentWallet, RepPrevWallet, OrderStatus, Status, ModifyDate)
              OUTPUT INSERTED.RepOrderID
              VALUES
              (@MemberID, @MID, @OrderNo, @OrderDate, @RepCurrentWallet, @RepPrevWallet, @OrderStatus, @Status, @ModifyDate) 
            `);

          kotid = insertHeaderResult.recordset[0].RepOrderID;

          for (let i = 0; i < kotbills.length; i++) {
            const item = kotbills[i];

            const netAmount = Number(item.MRP) * Number(item.Qty);

            tBV = tBV + Number(item.BV) * Number(item.Qty);
            tAMT = tAMT + Number(item.MRP) * Number(item.Qty);

            const PID = Number(item.pID);
            const productResult = await pool
              .request()
              .input("PID", sql.BigInt, PID)
              .query(`SELECT * FROM ProductMaster WHERE ID = @PID`);

            const Pobj = productResult.recordset[0];

            const lgst = (Number(item.MRP) * Number(Pobj.GST)) / 100;
            tgst = tgst + (Number(item.MRP) * Number(Pobj.GST)) / 100;

            await pool
              .request()
              .input("RepOrderID", sql.BigInt, kotid)
              .input("MemberID", sql.NVarChar, userName)
              .input("MID", sql.BigInt, MID)
              .input("pID", sql.BigInt, item.pID)
              .input("pCatID", sql.BigInt, item.pCatID)
              .input("MRP", sql.Decimal(18, 2), item.MRP)
              .input("BV", sql.Decimal(18, 2), item.BV)
              .input("Qty", sql.Int, item.Qty)
              .input("ModifyDate", sql.DateTime, new Date())
              .input("NetAmount", sql.Decimal(18, 2), netAmount)
              .input("Status", sql.NVarChar, "Active")
              .input("LGST", sql.Decimal(18, 2), lgst).query(`
                INSERT INTO RepProductOrderList
                  (RepOrderID, MemberID, MID, pID, pCatID, MRP, BV, Qty, ModifyDate, NetAmount, Status, LGST)
                VALUES
                  (@RepOrderID, @MemberID, @MID, @pID, @pCatID, @MRP, @BV, @Qty, @ModifyDate, @NetAmount, @Status, @LGST)
              `);
          }

          await pool
            .request()
            .input("RepOrderID", sql.BigInt, kotid)
            .input("TotalBV", sql.Decimal(18, 2), tBV)
            .input("TotalAmount", sql.Decimal(18, 2), tAMT)
            .input("TotalGST", sql.Decimal(18, 2), tgst).query(`
              UPDATE RepProductOrder
              SET TotalBV = @TotalBV,
                  TotalAmount = @TotalAmount,
                  TotalGST = @TotalGST
              WHERE RepOrderID = @RepOrderID
            `);
        }
      }
    }

    return res.json({
      success: true,
      orderId: kotid,
      message: "Order placed successfully",
    });
  } catch (error) {
    console.error("InsertRepProduct Error:", error);
    return res.status(500).json({ success: false, message: "Server Error" });
  }
};
